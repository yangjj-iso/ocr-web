"""Infrastructure adapters."""

