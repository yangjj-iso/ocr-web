"""External interfaces layer."""

